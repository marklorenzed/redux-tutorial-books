export default function() {
    return [
        {title: 'Javascript: The Good Parts' },
        {title: 'Harry Potter' },
        {title: 'The Dark Tower'},
        {title: 'Eloquent Ruby'}
    ];
}